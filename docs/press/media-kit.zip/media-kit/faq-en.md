# FAQ (English)

**Is 3ds2apple an emulator?**
No. It is a native port: game code is statically recompiled to C on the user's computer, built
into an ARM64 GamePack and executed natively. There is no CPU emulator, CPU JIT or interpreter
fallback.

**What are the main features?**
3ds2apple has an iOS-style grouped Settings page and an in-game menu in the same language with
native push/pop sub-pages, a default virtual-control layout from two Delta reference skins
(ModernFS portrait, ModernHybrid landscape), an always-visible Settings button, an Azahar-style
performance overlay at the top edge of the picture, and landscape layouts flush to the top edge
with SAVE/LOAD beside the notch. There are Windows, macOS and Linux launchers; the Linux one ships
a bundled local AOT toolchain (3dsrecomp + LLVM/LLD 23.1.6) and can build GamePacks from the
user's ROM locally.

**Where do the games come from?**
From the user. 3ds2apple ships no ROMs, decryption keys, BIOS or game assets and provides no
download links or piracy support. Only legally owned, self-dumped, decrypted ROMs are supported.

**Do I need a jailbreak?**
No. The app is signed with the user's own Apple ID (Impactor on Windows, Xcode automatic signing
on macOS, bundled plumesign-linux on Linux) and installed with Developer Mode enabled. A free
Apple ID allows 3 apps per device and about 7 days of signing; re-deploy to refresh.

**Does every game work?**
No. Compatibility and performance are per title and not guaranteed. Some titles may fail to
boot or render incorrectly; a few menus in some titles can still show corrupted graphics
(issue #2).

**Why is there no CPU JIT?**
iOS does not allow JIT-compiled executable memory, and the project keeps the shipping path AOT
by design. If an interpreter is detected the app refuses to start.

**Do cheat codes work?**
Yes, with the user's own codes. The app imports, edits, toggles and exports Citra/Azahar cheat text
files per title (Settings → Cheats) and switches them live from the in-game menu's Cheats page. No
cheat database is bundled or downloaded, and only data patches are supported — codes that rewrite
the game's code can slow an AOT build down.

**Which platform is verified?**
The Windows and Linux launchers are the verified paths. The macOS launcher ships with 0.3.1, but
its package is not self-contained yet and real-device installation is unverified (issue #1).

**Does the app collect data or make network requests?**
No. There are no analytics, no accounts and no network requests; diagnostics are exported
manually by the user. The optional update check contacts GitHub only when enabled.

**Media contact?**
GitHub Issues and Discussions only; there is no press email address.
