# FAQ (English)

**Is 3ds2apple an emulator?**
No. It is a native port: game code is statically recompiled to C on the user's computer, built
into an ARM64 GamePack and executed natively. There is no CPU emulator, CPU JIT or interpreter
fallback.

**Where do the games come from?**
From the user. 3ds2apple ships no ROMs, decryption keys, BIOS or game assets and provides no
download links or piracy support. Only legally owned, self-dumped, decrypted ROMs are supported.

**Do I need a jailbreak?**
No. The app is signed with the user's own Apple ID (Impactor on Windows, Xcode automatic
signing on macOS) and installed with Developer Mode enabled. A free Apple ID allows 3 apps per
device and about 7 days of signing; re-deploy to refresh.

**Does every game work?**
No. Compatibility and performance are per title and not guaranteed. Some titles may fail to
boot or render incorrectly; a few menus in some titles can still show corrupted graphics
(issue #2).

**Why is there no CPU JIT?**
iOS does not allow JIT-compiled executable memory, and the project keeps the shipping path AOT
by design. If an interpreter is detected the app refuses to start.

**Which platform is verified?**
The Windows launcher is the verified path. The macOS launcher is a developer preview: not
self-contained yet and real-device install is unverified (issue #1).

**Does the app collect data or make network requests?**
No. There are no analytics, no accounts and no network requests; diagnostics are exported
manually by the user.

**Media contact?**
GitHub Issues and Discussions only; there is no press email address.
