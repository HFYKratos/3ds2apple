# Legal disclaimer

3ds2apple is an independent, open-source project. It is **not affiliated with, endorsed by or
sponsored by Nintendo**. Nintendo 3DS is a trademark of Nintendo Co., Ltd. All other trademarks
belong to their respective owners.

3ds2apple ships **no** Nintendo ROMs, decryption keys, BIOS, system files, fonts, game assets,
gameplay screenshots or signed IPAs, and provides no ROM download links or piracy support. Only
decrypted games that the user legally owns and dumps themselves are supported.

Copyright in the application, launchers, scripts and documentation belongs to the 3ds2apple
contributors and is licensed under the Apache License 2.0. Third-party components and their
licences are listed in `THIRD_PARTY.md` and `NOTICE`.

The images in this media kit are project-owned synthetic previews (simulator test-harness
grids and launcher demo entries). They contain no game art. Press may reuse them unmodified
with credit to "3ds2apple (HFYKratos)", without implying endorsement. See
`CREDITS.md` for provenance.

Media contact: GitHub Issues and Discussions at
https://github.com/HFYKratos/3ds2apple — there is no press email address.
