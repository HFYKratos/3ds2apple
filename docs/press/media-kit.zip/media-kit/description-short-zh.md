# 短描述（简体中文）

3ds2apple 是一款免费开源的原生移植工具：它把你自有的 Nintendo 3DS 游戏提前重编译为原生
ARM64，直接运行在 iPhone 与 iPad 上——图形经 MoltenVK 走 Metal，没有 CPU JIT，也没有解释器
兜底。Windows 与 macOS 启动器包办导入、编译、签名、安装与数据推送。请自备合法拥有并自行导出
的游戏。当前版本 0.1.5，Apache-2.0。
