# 短描述（简体中文，约 100 字）

3ds2apple 是一款免费开源的原生移植工具：它把你自有的 Nintendo 3DS 游戏提前重编译为原生
ARM64，直接运行在 iPhone 与 iPad 上——图形经 MoltenVK 走 Metal，没有 CPU JIT，也没有解释器
兜底。Windows、macOS 与 Linux 启动器包办导入、编译、签名、安装与数据推送。App 采用 iOS 风格
分组设置页，默认按键布局基于两份 Delta 参考皮肤，设置按钮不可隐藏，Azahar 风格性能覆盖层贴在
画面顶端，横屏布局也贴住画面顶部。请自备合法拥有并自行导出的游戏。当前版本 0.3.0，Apache-2.0。
