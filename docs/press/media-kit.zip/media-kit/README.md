# 3ds2apple media kit — v0.3.1

Contents of the 0.3.1 media kit (released 2026-11-28). The in-game/layout/overlay screenshots are
the 0.2.1 synthetic set; the hero, Open Graph image and demo GIF were rebuilt for 0.3.1 from the
current compliant app and launcher captures, as were the iOS Settings, Windows, macOS and Linux
launcher screenshots. All images are synthetic or headless captures of the project's own launchers.

Contents
- fact-sheet-en.md / fact-sheet-zh.md — one-page facts, English and Simplified Chinese
- description-short-en.md / description-short-zh.md — one-paragraph descriptions
- description-long-en.md / description-long-zh.md — long-form descriptions
- faq-en.md / faq-zh.md — press FAQ
- demo-video-shot-list.md — shot list for the demo video (not recorded yet; no URL)
- legal.md — legal disclaimer and no-affiliation statement
- CREDITS.md — provenance of every image (all synthetic, project-owned)
- logos/ — app icon at 512 px, 256 px, 180 px (touch icon) and the SVG favicon
- images/ — hero, portrait, landscape, demo.gif and the Open Graph image
- screenshots/ — 20 screenshots: 9 synthetic 0.2.1 in-game/layout/overlay captures, 3 iOS 0.3.1 device Settings captures, 3 Windows 0.3.1 captures, 3 macOS 0.3.1 headless captures and 2 Linux 0.3.1 headless captures

Usage: editorial coverage of 3ds2apple is welcome. Please keep the "synthetic preview, no game
data" context, credit "3ds2apple (HFYKratos)", and do not imply endorsement — especially not by
Nintendo. Do not edit the images to add game art or commercial game names.

Media contact: GitHub Issues and Discussions at https://github.com/HFYKratos/3ds2apple.
