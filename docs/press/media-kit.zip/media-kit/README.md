# 3ds2apple media kit — v0.3.1

Contents of the 0.3.1 media kit (released 2026-11-28). The app and launcher screenshots, the
hero, the Open Graph image and the demo GIF are the 0.2.1 synthetic set; the two Linux launcher
captures are a 0.3.1 headless capture. All images are synthetic and project-owned.

Contents
- fact-sheet-en.md / fact-sheet-zh.md — one-page facts, English and Simplified Chinese
- description-short-en.md / description-short-zh.md — one-paragraph descriptions
- description-long-en.md / description-long-zh.md — long-form descriptions
- faq-en.md / faq-zh.md — press FAQ
- demo-video-shot-list.md — shot list for the demo video (not recorded yet; no URL)
- legal.md — legal disclaimer and no-affiliation statement
- CREDITS.md — provenance of every image (all synthetic, project-owned)
- logos/ — app icon at 512 px, 256 px, 180 px (touch icon) and the SVG favicon
- images/ — hero, portrait, landscape, demo.gif and the Open Graph image
- screenshots/ — 18 synthetic app and launcher screenshots (16 0.2.1 captures plus 2 Linux launcher 0.3.1 captures)

Usage: editorial coverage of 3ds2apple is welcome. Please keep the "synthetic preview, no game
data" context, credit "3ds2apple (HFYKratos)", and do not imply endorsement — especially not by
Nintendo. Do not edit the images to add game art or commercial game names.

Media contact: GitHub Issues and Discussions at https://github.com/HFYKratos/3ds2apple.
