# Long description (English)

3ds2apple brings your own Nintendo 3DS games to iPhone and iPad as a native port, not an
emulator. Each game is statically recompiled to C on your Windows or macOS computer, built
into an ARM64 GamePack with a local LLVM or Apple clang toolchain, and executed natively on
the phone through the Zakuro HLE runtime. Graphics take the Metal path via MoltenVK, and the
GPU presenter draws the screen-layout presets with no per-frame screen readback. There is no
CPU JIT and no interpreter fallback on the device.

One signed app holds the whole selected library: every game is its own GamePack plus a
GameCatalog, and game data is pushed separately into the app's Documents folder, so adding or
removing a title is a re-deploy and pushed data survives reinstalls. The on-screen pad is the
complete New 3DS set — D-pad, A/B/X/Y, L/R, ZL/ZR, Start/Select, an analog Circle Pad and the
C-stick — with in-game drag-to-edit layout, per-control visibility, 10–200% sizes and opacity
from the pause menu. Version 0.1.5 adds a full-bleed game view, six landscape and three
portrait screen layouts, and the Virtual controls card. The Windows launcher is the verified
path; the macOS launcher is a developer preview. 3ds2apple is free and open source under
Apache-2.0, ships no ROMs, keys, BIOS or game assets, and is not affiliated with Nintendo.
