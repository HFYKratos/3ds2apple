# Long description (English, ~190 words)

3ds2apple brings your own Nintendo 3DS games to iPhone and iPad as a native port, not an emulator.
Each game is statically recompiled to C on your Windows, macOS or Linux computer, built into an ARM64
GamePack with a local LLVM or Apple clang toolchain (the Linux launcher bundles its own 3dsrecomp +
LLVM/LLD 23.1.6), and executed natively on the phone through the Zakuro HLE runtime. Graphics take the
Metal path via MoltenVK, and the GPU presenter draws every screen layout — presets and custom
rectangles — with no per-frame screen readback. There is no CPU JIT and no interpreter fallback on the
device.

One signed app holds the whole selected library: every game is its own GamePack plus a GameCatalog,
and game data is pushed separately into the app's Documents folder, so adding or removing a title is
a re-deploy and pushed data survives reinstalls. The on-screen pad is the complete New 3DS set, with
in-game drag-to-edit layout, per-control visibility, 10–200% sizes and opacity from the pause menu.
The app has iOS 26/27 grouped Settings and an in-game menu in the same language with native
push/pop sub-pages, a default control layout from two Delta reference skins, an always-visible
Settings button in the skins' HOME slot, an Azahar-style performance overlay at the top edge of the
picture, and landscape layouts flush to the top edge with SAVE/LOAD beside the notch. It also
includes true unlimited speed, Stable/Beta update channels, a full gamepad layer, per-application
settings, Integer scaling and Screen aspect under Graphics, and your own Citra/Azahar cheat files. The launchers
also export portable .32a build packages and unsigned single-game IPAs. Windows, macOS and Linux launchers share
their import and build-package formats; the Linux launcher also bundles the local AOT toolchain and
signing with plumesign-linux. The Windows and Linux launchers are the verified paths; the macOS
launcher ships with 0.3.1 but its real-device installation is still unverified (issue #1).
3ds2apple is free and open source under Apache-2.0, ships no ROMs, keys, BIOS or game assets, and is
not affiliated with Nintendo.
