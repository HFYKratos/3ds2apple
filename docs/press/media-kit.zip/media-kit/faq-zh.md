# 常见问题（简体中文）

**3ds2apple 是模拟器吗？**
不是。它是原生移植：游戏代码先在电脑上静态重编译为 C，编译成 ARM64 GamePack 后原生执行；
没有 CPU 模拟器、没有 CPU JIT，也没有解释器兜底。

**主要功能有哪些？**
App 采用 iOS 风格分组式设置页，游戏内菜单使用相同的分组语言并支持原生 push/pop 子页；
默认虚拟按键布局基于两套 Delta 参考皮肤（竖屏 ModernFS、横屏 ModernHybrid），设置按钮
不可隐藏且关闭虚拟按键后仍常显；Azahar 风格性能覆盖层贴在画面顶端；横屏布局贴顶，
SAVE/LOAD 位于刘海旁。启动器覆盖 Windows、macOS 与 Linux；Linux 启动器内置本地 AOT 工具链
（3dsrecomp + LLVM/LLD 23.1.6），可直接从用户自有的 ROM 在本地构建 GamePack。

**游戏从哪里来？**
来自用户自己。3ds2apple 不附带 ROM、解密密钥、BIOS 或游戏资源，也不提供下载链接或盗版
支持；只支持用户合法拥有、自行导出并解密的 ROM。

**需要越狱吗？**
不需要。App 用用户自己的 Apple ID 签名（Windows 用 Impactor，macOS 用 Xcode 自动签名，
Linux 用内置 plumesign-linux），在开启开发者模式的设备上安装。免费 Apple ID 每台设备允许
3 个 App、签名约 7 天；重新部署即可续期。

**所有游戏都能玩吗？**
不能。兼容性与性能因游戏而异，不提供保证。部分游戏可能无法启动或渲染异常；个别游戏的某些
菜单仍可能出现花屏（issue #2）。

**为什么没有 CPU JIT？**
iOS 不允许 JIT 编译的可执行内存，项目也刻意让发布路径保持 AOT。一旦检测到解释器，App 会
拒绝启动。

**哪个平台已验证？**
Windows 与 Linux 启动器是已验证路径。macOS 启动器随 0.3.0 发布，但安装包尚未自包含，真机
安装尚未验证（issue #1）。

**App 会收集数据或联网吗？**
不会。没有统计、没有账号、不发网络请求；诊断报告由用户手动导出。可选的更新检查只在启用时
访问 GitHub。

**媒体联络方式？**
仅 GitHub Issues 与 Discussions，没有媒体邮箱。
