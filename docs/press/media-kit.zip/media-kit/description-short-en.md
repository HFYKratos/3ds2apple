# Short description (English, ~60 words)

3ds2apple is a free, open-source native port that recompiles your own Nintendo 3DS games to
native ARM64 ahead of time and runs them on iPhone and iPad — Metal through MoltenVK, no CPU JIT,
no interpreter fallback. Windows and macOS launchers handle import, compilation, signing, install
and data push. Version 0.2.1 refines the iOS-style grouped Settings and in-game menu, adds a
default control layout from two Delta reference skins, an always-visible Settings button, an
Azahar-style performance overlay and top-aligned landscape layouts. Bring your own legally owned,
dumped games. Version 0.2.1, Apache-2.0.
