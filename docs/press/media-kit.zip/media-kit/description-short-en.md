# Short description (English)

3ds2apple is a free, open-source native port that recompiles your own Nintendo 3DS games
to native ARM64 ahead of time and runs them on iPhone and iPad — Metal through MoltenVK,
no CPU JIT, no interpreter fallback. Windows and macOS launchers handle import, compilation,
signing, install and data push. Bring your own legally owned, dumped games. Version 0.1.5,
Apache-2.0.
