# Short description (English)

3ds2apple is a free, open-source native port that recompiles your own Nintendo 3DS games
to native ARM64 ahead of time and runs them on iPhone and iPad — Metal through MoltenVK,
no CPU JIT, no interpreter fallback. Windows and macOS launchers handle import, compilation,
signing, install and data push. Version 0.2.0 adds grouped iOS 26/27 Settings, a redesigned
in-game menu, true unlimited speed, Stable/Beta update channels, a full gamepad layer and
per-application settings. Bring your own legally owned, dumped games. Version 0.2.0,
Apache-2.0.
