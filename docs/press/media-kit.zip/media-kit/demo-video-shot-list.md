# Demo video — shot list (to be recorded by the maintainer)

> **Status: not recorded. There is no video URL yet.** This page intentionally contains no
> video link. When the video exists, the maintainer should add the real URL to the press kit
> and the README; until then, do not publish a placeholder link as if it were the video.

- Target length: 2:00–2:20, 16:9, 1080p or 4K.
- Everything shown must be **synthetic**: the app's preview harness (blue/purple grids
  labelled TOP 400×240 and BOTTOM 320×240), launcher demo entries, or blurred/synthetic
  content. **Never show commercial game footage, logos, box art or save data.**
- Record the phone with QuickTime/ReplayKit and the desktop with OBS or the built-in
  recorder; no copyrighted music — use the project's own or a neutral bed.
- Titles cards should read: "3ds2apple 0.3.1 — synthetic preview; no game data".

| Time | Shot | Notes |
|---|---|---|
| 0:00–0:08 | Title card | Icon, wordmark, "native ARM64 · Metal via MoltenVK · no CPU JIT". |
| 0:08–0:22 | Windows launcher: import | Open Library → Import, show a synthetic ROM fixture; keep filenames blurred or synthetic. macOS and Linux launchers share the flow. |
| 0:22–0:40 | Windows launcher: deploy | Select two synthetic entries → Deploy: compile GamePacks, compose/sign/install the IPA, push data. Show the incremental deploy summary. |
| 0:40–0:58 | iPhone portrait gameplay | Full-bleed preview grid, top-edge performance overlay, controls below the picture with the HOME-slot Settings button; show an on-screen Turbo toggle and the unlimited-speed warning. |
| 0:58–1:12 | In-game menu | Open the Settings button: game name in the header, Save state / Virtual controls / Screen layout / Swap screens / Rotate screen / Global Settings / Per-Application Settings / Close game, with the single slide-up animation; show Toggle controls (no Settings row), then hide the pad so only the Settings button remains. |
| 1:12–1:28 | Grouped Settings tour | General → System → Gamepad → Graphics → Layout → Sound → Debug → Other; show the two-line descriptions, Layout → Performance monitoring → Performance overlay (top-edge overlay, six positions) and Graphics → Integer scaling / Screen aspect. |
| 1:28–1:44 | Gamepad + per-app settings | Analog deadzone, button remapping, a 2–4 button hotkey recording, Standard/High contrast appearance, then Per-Application Settings overrides. |
| 1:44–1:56 | Launchers + library | Windows, macOS and Linux launcher library screens, then the phone library; update-channel row in General. |
| 1:56–2:08 | Outro | GitHub repo, releases, Apache-2.0, "bring your own games", "not affiliated with Nintendo". |

Acceptance for the recording: no commercial game name spoken or shown; no ROM/BIOS/key content;
no device UDID or Apple ID visible; captions state "synthetic preview".
