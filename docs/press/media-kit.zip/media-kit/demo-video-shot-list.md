# Demo video — shot list (to be recorded by the maintainer)

> **Status: not recorded. There is no video URL yet.** This page intentionally contains no
> video link. When the video exists, the maintainer should add the real URL to the press kit
> and the README; until then, do not publish a placeholder link as if it were the video.

- Target length: 1:50–2:00, 16:9, 1080p or 4K.
- Everything shown must be **synthetic**: the app's preview harness (blue/purple grids
  labelled TOP 400×240 and BOTTOM 320×240), launcher demo entries, or blurred/synthetic
  content. **Never show commercial game footage, logos, box art or save data.**
- Record the phone with QuickTime/ReplayKit and the desktop with OBS or the built-in
  recorder; no copyrighted music — use the project's own or a neutral bed.
- Titles cards should read: "3ds2apple 0.1.6 — synthetic preview; no game data".

| Time | Shot | Notes |
|---|---|---|
| 0:00–0:08 | Title card | Icon, wordmark, "native ARM64 · Metal via MoltenVK · no CPU JIT". |
| 0:08–0:22 | Windows launcher: import | Open Library → Import, show a synthetic ROM fixture; keep filenames blurred or synthetic. |
| 0:22–0:40 | Windows launcher: deploy | Select two synthetic entries → Deploy: compile GamePacks, compose/sign/install the IPA, push data. Show the incremental deploy summary. |
| 0:40–0:58 | iPhone, portrait, gameplay | Full-bleed preview grid, floating FPS pill, controls below the picture, single-cross D-pad press; show the fast-forward / quick save / quick load / swap buttons. |
| 0:58–1:12 | Pause menu → Virtual controls | Toggle controls, adjust size 100%→150%, opacity, Edit layout drag, centred Done. |
| 1:12–1:26 | Settings → Display → Screen layout | Cycle the six landscape presets, then a custom rectangle layout with rotation and screen swap. |
| 1:26–1:38 | Portrait layouts + C-stick | Default / Original / Custom; show the portrait control band and enable the C-stick. |
| 1:38–1:50 | Launchers + library | macOS launcher empty state, then a populated synthetic library; split screen with the phone. |
| 1:50–2:00 | Outro | GitHub repo, releases, Apache-2.0, "bring your own games", "not affiliated with Nintendo". |

Acceptance for the recording: no commercial game name spoken or shown; no ROM/BIOS/key content;
no device UDID or Apple ID visible; captions state "synthetic preview".
