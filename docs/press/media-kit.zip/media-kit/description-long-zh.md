# 长描述（简体中文）

3ds2apple 以原生移植而非模拟器的方式，把你自有的 Nintendo 3DS 游戏带到 iPhone 与 iPad。
每款游戏先在 Windows 或 macOS 电脑上被静态重编译为 C，再由本机 LLVM 或 Apple clang
工具链编译成 ARM64 GamePack，最后通过 Zakuro HLE 运行时在手机上原生执行。图形经
MoltenVK 走 Metal，屏幕布局预设由 GPU presenter 绘制，每帧零屏幕回读；手机端没有 CPU
JIT，也没有解释器兜底。

一个已签名 App 装下你选定的整个游戏库：每款游戏是独立的 GamePack 加 GameCatalog，
游戏数据单独推送到 App 的 Documents 目录，因此增删一款游戏只需重新部署，已推送的数据在
重装后仍然保留。屏幕上的虚拟按键是完整的 New 3DS 键位——十字键、A/B/X/Y、L/R、ZL/ZR、
Start/Select、真模拟量 Circle Pad 与 C 杆——并可在暂停菜单里游戏内拖动编辑布局、逐键显隐、
调整 10%–200% 的大小与透明度。0.1.5 带来全屏游戏画面、横向六种与纵向三种屏幕布局，以及
「虚拟按键选项」卡片。Windows 启动器是已验证路径；macOS 启动器为开发者预览。3ds2apple
以 Apache-2.0 免费开源，不附带 ROM、密钥、BIOS 或游戏资源，与 Nintendo 无隶属关系。
