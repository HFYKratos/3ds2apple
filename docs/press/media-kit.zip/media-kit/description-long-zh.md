# 长描述（简体中文，约 300 字）

3ds2apple 以原生移植而非模拟器的方式，把你自有的 Nintendo 3DS 游戏带到 iPhone 与 iPad。
每款游戏先在 Windows、macOS 或 Linux 电脑上被静态重编译为 C，再由本机 LLVM 或 Apple clang
工具链（Linux 启动器自带 3dsrecomp + LLVM/LLD 23.1.6）编译成 ARM64 GamePack，最后通过
Zakuro HLE 运行时在手机上原生执行。图形经 MoltenVK 走 Metal，所有屏幕布局（预设与自定义矩形）
由 GPU presenter 绘制，每帧零屏幕回读；手机端没有 CPU JIT，也没有解释器兜底。

一个已签名 App 装下你选定的整个游戏库：每款游戏是独立的 GamePack 加 GameCatalog，游戏数据
单独推送到 App 的 Documents 目录，因此增删一款游戏只需重新部署，已推送的数据在重装后仍然
保留。屏幕上的虚拟按键是完整的 New 3DS 键位，并可在暂停菜单里游戏内拖动编辑布局、逐键显隐、
调整 10%–200% 的大小与透明度。App 采用 iOS 26/27 分组式设置页，游戏内菜单使用相同的分组语言
并支持原生 push/pop 子页；默认按键布局基于两份 Delta 参考皮肤，设置按钮固定显示在皮肤 HOME 槽、
不可隐藏；Azahar 风格性能覆盖层贴在画面顶端，横屏布局贴住画面顶部、SAVE/LOAD 位于刘海旁。
此外还包括真正无限制速度、Stable/Beta 更新通道、完整手柄层、按游戏设置，以及图形设置中的
Integer scaling 与 Screen aspect。Windows、macOS 与 Linux 启动器共用导入与构建包格式；Linux
启动器还内置本地 AOT 工具链，并用内置 plumesign-linux 签名安装。Windows 与 Linux 启动器是
已验证路径；macOS 启动器随 0.3.0 发布，但真机安装仍以 issue #1 的验收进展为准。3ds2apple 以
Apache-2.0 免费开源，不附带 ROM、密钥、BIOS 或游戏资源，与 Nintendo 无隶属关系。
