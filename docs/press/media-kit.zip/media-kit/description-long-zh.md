# 长描述（简体中文）

3ds2apple 以原生移植而非模拟器的方式，把你自有的 Nintendo 3DS 游戏带到 iPhone 与 iPad。
每款游戏先在 Windows 或 macOS 电脑上被静态重编译为 C，再由本机 LLVM 或 Apple clang
工具链编译成 ARM64 GamePack，最后通过 Zakuro HLE 运行时在手机上原生执行。图形经
MoltenVK 走 Metal，GPU presenter 绘制所有屏幕布局——横向六种、纵向三种预设，外加任意
自定义矩形——每帧零屏幕回读；手机端没有 CPU JIT，也没有解释器兜底。

一个已签名 App 装下你选定的整个游戏库：每款游戏是独立的 GamePack 加 GameCatalog，
游戏数据单独推送到 App 的 Documents 目录，因此增删一款游戏只需重新部署，已推送的数据在
重装后仍然保留。屏幕上的虚拟按键是完整的 New 3DS 键位——十字键、A/B/X/Y、L/R、ZL/ZR、
Start/Select、真模拟量 Circle Pad 与 C 杆——并可在暂停菜单里游戏内拖动编辑布局、按方向显隐、
调整 10%–200% 的大小与透明度。0.2.0 是设置与游戏内体验版本：iOS 26/27 分组式设置、带原生
push/pop 子页的重做游戏内菜单、真正无限制速度、Stable/Beta 更新通道、完整手柄层（模拟死区、
物理按键重映射、2–4 键 hotkey、Standard/High contrast 控件外观、按游戏 profile）与按 title ID
的按游戏设置，并在图形设置中加入 Integer scaling 与 Screen aspect；0.1.6 已带来 GPU 自定义
屏幕布局（四种旋转与屏幕交换）与 Windows 增量部署；0.1.5 已带来全屏游戏画面、横向六种与
纵向三种屏幕布局，以及「虚拟按键选项」卡片。Windows 启动器是已验证路径；macOS 启动器为开发者
预览。3ds2apple 以 Apache-2.0 免费开源，不附带 ROM、密钥、BIOS 或游戏资源，与 Nintendo
无隶属关系。
