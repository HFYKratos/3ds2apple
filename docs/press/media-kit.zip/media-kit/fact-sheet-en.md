# 3ds2apple — fact sheet (English)

| Field | Detail |
|---|---|
| Product | 3ds2apple |
| One-liner | Your own Nintendo 3DS games, running natively on iPhone and iPad. |
| Version | 0.1.6 (released 2026-11-23) |
| Platforms | iPhone / iPad on iOS 16+ · Windows 10/11 launcher · macOS 13+ launcher (Intel + Apple silicon) |
| Components | Windows launcher (C#/Avalonia, single executable) · macOS launcher (SwiftUI, Xcode signing) · iOS app |
| Rendering | Static recompilation to native ARM64; Metal through MoltenVK; the GPU presenter draws every screen layout — presets and custom rectangles — with no per-frame screen readback |
| No JIT | No CPU JIT and no interpreter fallback on the phone; AOT only |
| 0.1.6 highlights | GPU custom screen layouts with four-way rotation and screen swap; fast-forward toggle; quick save / quick load; swap screens; per-orientation control visibility; full-screen editors; Metal HUD off by default; device-aware incremental Windows deploy |
| Licence | Apache-2.0 (open source, free) |
| Price | Free |
| Downloads | https://github.com/HFYKratos/3ds2apple/releases (two platform zips) |
| Source | https://github.com/HFYKratos/3ds2apple |
| Website | https://hfykratos.github.io/3ds2apple/ |
| Status | Windows launcher is the verified path; macOS launcher is a developer preview and its real-device install is unverified (issue #1) |
| Known issues | Some menus in some titles can render incorrectly (issue #2). Custom layouts run on the GPU presenter since 0.1.6; only a device without a usable presenter keeps the readback fallback. |
| Requirements | A decrypted 3DS ROM the user legally owns and dumped; Developer Mode; USB cable; the user's own Apple ID for signing |
| Included content | No games, ROMs, keys, BIOS or game data. Launchers, app and documentation only. |
| Media contact | GitHub Issues and Discussions (no press email) |
| Affiliation | Not affiliated with, endorsed by or sponsored by Nintendo. Nintendo 3DS is a trademark of Nintendo Co., Ltd. |
| Media assets | `media-kit.zip` / `docs/assets/CREDITS.md` — all synthetic, project-owned |
