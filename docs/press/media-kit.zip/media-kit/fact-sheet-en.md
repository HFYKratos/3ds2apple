# 3ds2apple — fact sheet (English)

| Field | Detail |
|---|---|
| Product | 3ds2apple |
| One-liner | Your own Nintendo 3DS games, running natively on iPhone and iPad. |
| Version | 0.3.1 (released 2026-11-28) |
| Platforms | iPhone / iPad on iOS 16+ · Windows 10/11 launcher · macOS 13+ launcher (Intel + Apple silicon) · Linux x86_64 launcher |
| Components | Windows launcher (C#/Avalonia, single executable) · macOS launcher (SwiftUI, Xcode signing) · Linux launcher (shared Avalonia/Core) · iOS app |
| Rendering | Static recompilation to native ARM64; Metal through MoltenVK; the GPU presenter draws every screen layout — presets and custom rectangles — with no per-frame screen readback |
| No JIT | No CPU JIT and no interpreter fallback on the phone; AOT only |
| Highlights | iOS 26/27 grouped Settings; a default virtual-control layout from two Delta reference skins (ModernFS portrait, ModernHybrid landscape) with the Settings button in the HOME slot and SAVE/LOAD beside the notch; the Settings button can never be hidden and stays when the pad is off; an Azahar-style performance overlay at the top edge of the picture; an in-game menu in the same iOS grouped language with a slide-up animation and native push/pop sub-pages; landscape Large / Side by side / Hybrid layouts flush to the top edge, with SAVE/LOAD beside the notch; the Linux launcher ships a bundled local AOT toolchain (3dsrecomp + LLVM/LLD 23.1.6) |
| Licence | Apache-2.0 (open source, free) |
| Price | Free |
| Downloads | https://github.com/HFYKratos/3ds2apple/releases (three platform packages) |
| Source | https://github.com/HFYKratos/3ds2apple |
| Website | https://hfykratos.github.io/3ds2apple/ |
| Status | Windows and Linux launchers are the verified paths; the macOS launcher ships with 0.3.1 but is a developer preview and its real-device install is unverified (issue #1) |
| Known issues | Some menus in some titles can render incorrectly (issue #2). Delta-style skin import, a cheat manager, a manual viewer, amiibo, microphone, camera and network/online features are not part of the app; CPU JIT, shader JIT, RPC and LLE settings do not apply to the AOT-only architecture. |
| Requirements | A decrypted 3DS ROM the user legally owns and dumped; Developer Mode; USB cable; the user's own Apple ID for signing |
| Included content | No games, ROMs, keys, BIOS or game data. Launchers, app and documentation only. |
| Media contact | GitHub Issues and Discussions (no press email) |
| Affiliation | Not affiliated with, endorsed by or sponsored by Nintendo. Nintendo 3DS is a trademark of Nintendo Co., Ltd. |
| Media assets | media-kit.zip / docs/assets/CREDITS.md — all synthetic, project-owned |
