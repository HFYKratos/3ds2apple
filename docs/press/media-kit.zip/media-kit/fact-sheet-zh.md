# 3ds2apple — 事实清单（简体中文）

| 项目 | 说明 |
|---|---|
| 产品 | 3ds2apple |
| 一句话 | 把你自有的 Nintendo 3DS 游戏以原生方式运行在 iPhone 与 iPad 上。 |
| 版本 | 0.2.1（发布于 2026-11-25） |
| 平台 | iPhone / iPad（iOS 16+）· Windows 10/11 启动器 · macOS 13+ 启动器（Intel + Apple 芯片） |
| 组成 | Windows 启动器（C#/Avalonia，单文件）· macOS 启动器（SwiftUI，Xcode 签名）· iOS App |
| 渲染 | 静态重编译为原生 ARM64；经 MoltenVK 走 Metal；GPU presenter 绘制所有屏幕布局（预设与自定义矩形），每帧零屏幕回读 |
| 无 JIT | 手机端没有 CPU JIT、没有解释器兜底，只运行 AOT 代码 |
| 0.2.1 亮点 | iOS 26/27 分组式设置；基于两套 Delta 参考皮肤的默认虚拟按键布局（竖屏 ModernFS、横屏 ModernHybrid），皮肤 HOME 槽是设置按钮、SAVE/LOAD 位于刘海旁；设置按钮不可隐藏，关闭虚拟按键后仍常显；贴画面顶端的 Azahar 风格性能覆盖层；重做的游戏内菜单（单一上滑动画、原生 push/pop 子页）；横屏 Large / Side by side / Hybrid 布局贴顶，并修正刘海旁的 SAVE/LOAD 位置 |
| 许可 | Apache-2.0（开源免费） |
| 价格 | 免费 |
| 下载 | https://github.com/HFYKratos/3ds2apple/releases（两个平台 zip） |
| 源码 | https://github.com/HFYKratos/3ds2apple |
| 网站 | https://hfykratos.github.io/3ds2apple/zh/ |
| 状态 | Windows 启动器为已验证路径；macOS 启动器是开发者预览，真机安装尚未验证（issue #1） |
| 已知问题 | 个别游戏的某些菜单可能渲染异常（issue #2）。Delta 风格皮肤导入、金手指管理器、说明书查看器、amiibo、麦克风、摄像头与网络/在线功能不在 0.2.1 内；CPU JIT、着色器 JIT、RPC 与 LLE 设置不适用于纯 AOT 架构。 |
| 使用条件 | 用户合法拥有并自行导出的已解密 3DS ROM、开发者模式、USB 线，以及用户自己的 Apple ID 用于签名 |
| 附带内容 | 不含游戏、ROM、密钥、BIOS 或游戏数据，只有启动器、App 与文档 |
| 媒体联络 | GitHub Issues 与 Discussions（无媒体邮箱） |
| 隶属关系 | 与 Nintendo 无隶属、背书或赞助关系。Nintendo 3DS 是 Nintendo Co., Ltd. 的商标。 |
| 媒体素材 | media-kit.zip / docs/assets/CREDITS.md——全部为合成素材，项目自有 |
