# 3ds2apple — 事实清单（简体中文）

| 项目 | 说明 |
|---|---|
| 产品 | 3ds2apple |
| 一句话 | 把你自有的 Nintendo 3DS 游戏以原生方式运行在 iPhone 与 iPad 上。 |
| 版本 | 0.3.2（发布于 2026-11-28） |
| 平台 | iPhone / iPad（iOS 16+）· Windows 10/11 启动器 · macOS 13+ 启动器（Intel + Apple 芯片）· Linux x86_64 启动器 |
| 组成 | Windows 启动器（C#/Avalonia，单文件）· macOS 启动器（SwiftUI，Xcode 签名）· Linux 启动器（共用 Avalonia/Core）· iOS App |
| 渲染 | 静态重编译为原生 ARM64；经 MoltenVK 走 Metal；GPU presenter 绘制所有屏幕布局（预设与自定义矩形），每帧零屏幕回读 |
| 无 JIT | 手机端没有 CPU JIT、没有解释器兜底，只运行 AOT 代码。AOT 状态、覆盖率与解释执行/回退计数可在设置 → 调试页与诊断导出中查看 |
| 金手指 | 支持用户自备的 Citra/Azahar 金手指文本（按游戏），在「设置 → 金手指」与游戏内菜单中管理；不内置也不下载任何金手指数据库，只支持数据修改类代码 |
| 便携构建 | 可导出便携 `.32a` 构建包或未签名、自包含的单游戏 IPA；可导入 ROM 与 `.32a` 包并复用构建缓存；高级 AOT 选项位于启动器设置页，续签可就地续 7 天签名 |
| 亮点 | iOS 26/27 分组式设置；基于两套 Delta 参考皮肤的默认虚拟按键布局（竖屏 ModernFS、横屏 ModernHybrid），皮肤 HOME 槽是设置按钮、SAVE/LOAD 位于刘海旁；设置按钮不可隐藏，关闭虚拟按键后仍常显；贴画面顶端的 Azahar 风格性能覆盖层；游戏内菜单沿用相同的 iOS 分组语言，带单次上滑动画与原生 push/pop 子页；横屏 Large / Side by side / Hybrid 布局贴顶，SAVE/LOAD 位于刘海旁；Linux 启动器内置本地 AOT 工具链（3dsrecomp + LLVM/LLD 23.1.6）；完整手柄层与按游戏 profile；按游戏设置；便携 `.32a` 导出与未签名单游戏 IPA |
| 许可 | Apache-2.0（开源免费） |
| 价格 | 免费 |
| 下载 | https://github.com/HFYKratos/3ds2apple/releases（三个平台包） |
| 源码 | https://github.com/HFYKratos/3ds2apple |
| 网站 | https://hfykratos.github.io/3ds2apple/zh/ |
| 状态 | Windows 与 Linux 启动器为已验证路径；macOS 启动器随 0.3.2 发布，但仍是开发者预览，真机安装尚未验证（issue #1） |
| 已知问题 | Delta 风格皮肤导入、内置金手指数据库、说明书查看器、amiibo、麦克风、摄像头与网络/在线功能不在 App 内；CPU JIT、着色器 JIT、RPC 与 LLE 设置不适用于纯 AOT 架构。 |
| 使用条件 | 用户合法拥有并自行导出的已解密 3DS ROM、开发者模式、USB 线，以及用户自己的 Apple ID 用于签名 |
| 附带内容 | 不含游戏、ROM、密钥、BIOS 或游戏数据，只有启动器、App 与文档 |
| 媒体联络 | GitHub Issues 与 Discussions（无媒体邮箱） |
| 隶属关系 | 与 Nintendo 无隶属、背书或赞助关系。Nintendo 3DS 是 Nintendo Co., Ltd. 的商标。 |
| 媒体素材 | media-kit.zip / docs/assets/CREDITS.md——全部为合成素材，项目自有 |
